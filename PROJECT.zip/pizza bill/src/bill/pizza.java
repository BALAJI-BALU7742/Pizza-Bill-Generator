package bill;

import java.util.Scanner;

public class pizza {
	protected int price;
	private boolean veg;
	
	protected int extraCheesePrice=100;
	protected int extraToppingsPrice=150;
	protected int backpackPrice=20;
	
	protected int basePizzaPrice;
	private boolean isExtraCheeseAdded=false;
	private boolean isExtraToppingsAdded=false;
	private boolean isOptedForTakeAway=false;
	
	Scanner in=new Scanner(System.in);
	public pizza(boolean veg) {
		this.veg=veg;
		if (this.veg) {
			this.price=300;	
		}
		else {
			this.price=400;
		}
		basePizzaPrice=this.price;
	}
	public void addExtraCheese(){
		System.out.println("ExtraCheese (y/n)?=>");
		char ch=in.next().charAt(0);
		switch (ch) {
		case('y'):
			isExtraCheeseAdded=true;
		this.price+=extraCheesePrice;
		break;
		case ('n'):
			isExtraCheeseAdded=false;
		break;
		}
	}
	public void addExtraToppings() {
		System.out.println("want Extra Toppping (y/n)?=>");
		char ch=in.next().charAt(0);
		switch (ch) {
		case('y'):
			isExtraToppingsAdded=true;
		this.price+=extraToppingsPrice;
		break;
		case ('n'):
			isExtraToppingsAdded=false;
		break;
		}
		
	}
		public void takeAway() {
			System.out.println("want TakeAway (y/n)?=>");
			char ch=in.next().charAt(0);
			switch (ch) {
			case('y'):
				isOptedForTakeAway=true;
			this.price+=backpackPrice;
			break;
			case ('n'):
				isOptedForTakeAway=false;
			break;
		}
		}
			public void getBill(){
				String bill=" ";
				System.out.println("pizza:"+basePizzaPrice);
				if(isExtraCheeseAdded) {
					bill+="Extra Cheese: "+extraCheesePrice+"\n";
				}
				if(isExtraToppingsAdded) {
					bill+="Extra Toppings: "+extraToppingsPrice+"\n";
					}
				if(isOptedForTakeAway) {
					bill+="Take Away: "+backpackPrice+"\n";
				}
				bill+="/n Total Amount: "+this.price+"\n";
				System.out.println(bill);
				System.out.println("\n\n Thank You!!! Visit Again...........");
				System.out.println("----------------------------------------");
				}
			
				}
			
		
	
	
	


