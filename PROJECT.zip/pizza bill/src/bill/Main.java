package bill;

import java.util.Scanner;

public class Main {
public static void main(String[]args) {
	System.out.println("----------welcome to TastyPizza-------------");
	System.out.println("which pizza: 1.Veg pizza, 2.Non-veg pizza, 3.Delux veg pizza, 4.delux non-veg pizza");
	Scanner sc=new Scanner(System.in);
	int ch=sc.nextInt();
	
	switch(ch) {
	case 1:
		pizza vegpizza=new pizza(true);
		vegpizza.addExtraToppings();
		vegpizza.addExtraCheese();
		vegpizza.takeAway();
		vegpizza.getBill();
		break;
	case 2:
		pizza Nonvegpizza=new pizza(false);
		Nonvegpizza.addExtraToppings();
		Nonvegpizza.addExtraCheese();
		Nonvegpizza.takeAway();
		Nonvegpizza.getBill();
		break;
	case 3:
		DeluxPizza veg=new DeluxPizza(true);
		veg.basePizzaPrice=550;
		veg.addExtraToppings();
		veg.addExtraCheese();
		veg.addtakeAway();
		veg.getBill();
		break;
	case 4:
		DeluxPizza Nonveg=new DeluxPizza(false);
		Nonveg.basePizzaPrice=650;
		Nonveg.addExtraToppings();
		Nonveg.addExtraCheese();
		Nonveg.addtakeAway();
		Nonveg.getBill();
		break;
		
	default:
		System.out.println("sorry enter again!!!!!!");
		return;
		
	}
	sc.close();
}
}
