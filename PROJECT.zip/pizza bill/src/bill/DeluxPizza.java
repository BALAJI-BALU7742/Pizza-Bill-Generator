package bill;

public class DeluxPizza extends pizza {

	public DeluxPizza(boolean veg) {
		super(veg);
	}
	public void addExtraCheese() {
		this.price+=extraCheesePrice;
	}
	public void addExtraToppings() {
		this.price+=extraToppingsPrice;
	}
	public void addtakeAway() {
		this.price+=backpackPrice;
	}
	public void  getBill() {
		this.price+=price;
	}

}
